<?php
$Install = new Install();
?>
<section>
  <h3>Welcome to the V4.1 !</h3>
  <p>The update was successfull</p>
  <section class="kr-msg kr-msg-warning" style="display:block;">
    Don't forget to delete update folder !
  </section>
</section>
<footer>
  <div>
  </div>
  <div>
    <a href="../" class="btn-shadow btn-orange">LOGIN</a>
  </div>
</footer>
